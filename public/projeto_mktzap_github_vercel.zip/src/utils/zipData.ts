// Vercel placeholder for zipData
export const PROJECT_ZIP_BASE64 = "";
